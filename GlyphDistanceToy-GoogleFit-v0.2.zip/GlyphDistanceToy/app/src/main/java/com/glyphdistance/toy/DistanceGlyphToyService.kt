package com.glyphdistance.toy

import android.content.Context
import com.nothing.ketchum.GlyphMatrixManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class DistanceGlyphToyService : GlyphMatrixService() {
    private var scope: CoroutineScope? = null
    private var refreshJob: Job? = null

    override fun onGlyphConnected(context: Context, manager: GlyphMatrixManager) {
        scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        refreshJob = scope?.launch {
            while (isActive) {
                updateMatrix()
                delay(60_000L)
            }
        }
    }

    override fun onLongPress() {
        scope?.launch { updateMatrix() }
    }

    private suspend fun updateMatrix() {
        val km = try {
            DistanceRepository(applicationContext).todayKilometres()
        } catch (_: Exception) {
            Double.NaN
        }
        val frame = DistanceMatrixRenderer.render(km)
        glyphMatrixManager?.setMatrixFrame(frame)
    }

    override fun onGlyphDisconnected(context: Context) {
        refreshJob?.cancel()
        refreshJob = null
        scope?.cancel()
        scope = null
    }
}
