package com.glyphdistance.toy

import java.util.Locale
import kotlin.math.roundToInt

/** Renders a compact monochrome 25x25 frame for Nothing Phone (3). */
object DistanceMatrixRenderer {
    private const val W = 25
    private const val H = 25
    private const val ON = 255

    private val font = mapOf(
        '0' to listOf("111", "101", "101", "101", "111"),
        '1' to listOf("010", "110", "010", "010", "111"),
        '2' to listOf("111", "001", "111", "100", "111"),
        '3' to listOf("111", "001", "111", "001", "111"),
        '4' to listOf("101", "101", "111", "001", "001"),
        '5' to listOf("111", "100", "111", "001", "111"),
        '6' to listOf("111", "100", "111", "101", "111"),
        '7' to listOf("111", "001", "010", "010", "010"),
        '8' to listOf("111", "101", "111", "101", "111"),
        '9' to listOf("111", "101", "111", "001", "111"),
        '-' to listOf("000", "000", "111", "000", "000"),
        'K' to listOf("101", "110", "100", "110", "101"),
        'M' to listOf("101", "111", "111", "101", "101")
    )

    fun render(km: Double): IntArray {
        val pixels = IntArray(W * H)
        if (km.isNaN()) {
            drawText(pixels, "--", scale = 2, y = 5)
            drawText(pixels, "KM", scale = 1, y = 19)
            return pixels
        }

        val text = when {
            km < 10.0 -> String.format(Locale.US, "%.1f", km)
            km < 100.0 -> String.format(Locale.US, "%.1f", km)
            km < 1000.0 -> km.roundToInt().toString()
            else -> "999"
        }

        val scale = if (measure(text, 2) <= 23) 2 else 1
        val y = if (scale == 2) 4 else 7
        drawText(pixels, text, scale, y)
        drawText(pixels, "KM", scale = 1, y = 19)
        return pixels
    }

    private fun measure(text: String, scale: Int): Int {
        var width = 0
        text.forEachIndexed { i, c ->
            width += if (c == '.') scale else 3 * scale
            if (i != text.lastIndex) width += scale
        }
        return width
    }

    private fun drawText(buffer: IntArray, text: String, scale: Int, y: Int) {
        val total = measure(text, scale)
        var x = ((W - total) / 2).coerceAtLeast(0)
        text.forEachIndexed { index, c ->
            if (c == '.') {
                setBlock(buffer, x, y + 4 * scale, scale, scale)
                x += scale
            } else {
                val glyph = font[c] ?: font['-']!!
                glyph.forEachIndexed { row, bits ->
                    bits.forEachIndexed { col, bit ->
                        if (bit == '1') {
                            setBlock(buffer, x + col * scale, y + row * scale, scale, scale)
                        }
                    }
                }
                x += 3 * scale
            }
            if (index != text.lastIndex) x += scale
        }
    }

    private fun setBlock(buffer: IntArray, x: Int, y: Int, w: Int, h: Int) {
        for (yy in y until y + h) for (xx in x until x + w) {
            if (xx in 0 until W && yy in 0 until H) buffer[yy * W + xx] = ON
        }
    }
}
