package com.glyphdistance.toy

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.metadata.DataOrigin
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Reads only today's distance written to Health Connect by Google Fit. */
class DistanceRepository(context: Context) {
    private val client = HealthConnectClient.getOrCreate(context)

    companion object {
        /** Official Google Fit Android package. */
        const val GOOGLE_FIT_PACKAGE = "com.google.android.apps.fitness"
    }

    suspend fun hasDistancePermission(): Boolean {
        val required = HealthPermission.getReadPermission(DistanceRecord::class)
        return required in client.permissionController.getGrantedPermissions()
    }

    /**
     * Returns kilometres recorded by Google Fit from local midnight until now.
     * Nothing is deleted or reset in Health Connect: changing the start of the
     * query to today's midnight makes the displayed value naturally return to
     * zero when the local calendar day changes.
     */
    suspend fun todayKilometres(): Double {
        if (!hasDistancePermission()) return Double.NaN

        val zone = ZoneId.systemDefault()
        val start: Instant = LocalDate.now(zone).atStartOfDay(zone).toInstant()
        val end = Instant.now()

        val result = client.aggregate(
            AggregateRequest(
                metrics = setOf(DistanceRecord.DISTANCE_TOTAL),
                timeRangeFilter = TimeRangeFilter.between(start, end),
                dataOriginFilter = setOf(DataOrigin(GOOGLE_FIT_PACKAGE))
            )
        )

        return (result[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0) / 1000.0
    }
}
