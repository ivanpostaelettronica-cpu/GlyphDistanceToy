package com.glyphdistance.toy

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphMatrixManager
import com.nothing.ketchum.GlyphToy

abstract class GlyphMatrixService : Service() {
    protected var glyphMatrixManager: GlyphMatrixManager? = null
        private set

    private val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            if (msg.what == GlyphToy.MSG_GLYPH_TOY) {
                when (msg.data?.getString(GlyphToy.MSG_GLYPH_TOY_DATA)) {
                    GlyphToy.EVENT_CHANGE -> onLongPress()
                    GlyphToy.EVENT_ACTION_DOWN -> onPressDown()
                    GlyphToy.EVENT_ACTION_UP -> onPressUp()
                }
            } else super.handleMessage(msg)
        }
    }
    private val messenger = Messenger(handler)

    private val callback = object : GlyphMatrixManager.Callback {
        override fun onServiceConnected(name: ComponentName?) {
            glyphMatrixManager?.let {
                it.register(Glyph.DEVICE_23112)
                onGlyphConnected(applicationContext, it)
            }
        }
        override fun onServiceDisconnected(name: ComponentName?) = Unit
    }

    final override fun onBind(intent: Intent?): IBinder {
        glyphMatrixManager = GlyphMatrixManager.getInstance(applicationContext)
        glyphMatrixManager?.init(callback)
        return messenger.binder
    }

    final override fun onUnbind(intent: Intent?): Boolean {
        onGlyphDisconnected(applicationContext)
        glyphMatrixManager?.turnOff()
        glyphMatrixManager?.unInit()
        glyphMatrixManager = null
        return false
    }

    protected open fun onGlyphConnected(context: Context, manager: GlyphMatrixManager) = Unit
    protected open fun onGlyphDisconnected(context: Context) = Unit
    protected open fun onLongPress() = Unit
    protected open fun onPressDown() = Unit
    protected open fun onPressUp() = Unit
}
