package com.glyphdistance.toy

import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.DistanceRecord
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private val healthClient by lazy { HealthConnectClient.getOrCreate(this) }

    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { refreshStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun buildUi(): LinearLayout {
        fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 12, 0, 12)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 64, 48, 48)

            addView(TextView(context).apply {
                text = "Glyph Distance"
                textSize = 28f
                setTypeface(typeface, Typeface.BOLD)
            }, lp())

            addView(TextView(context).apply {
                text = "Mostra sulla Glyph Matrix la distanza registrata oggi da Google Fit tramite Health Connect."
                textSize = 17f
            }, lp())

            status = TextView(context).apply { textSize = 18f }
            addView(status, lp())

            addView(Button(context).apply {
                text = "Concedi accesso alla distanza"
                setOnClickListener { requestHealthPermissions() }
            }, lp())

            addView(Button(context).apply {
                text = "Leggi distanza Google Fit di oggi"
                setOnClickListener { refreshStatus(showDistance = true) }
            }, lp())

            addView(Button(context).apply {
                text = "Apri gestione Glyph Toys"
                setOnClickListener { openGlyphToyManager() }
            }, lp())

            addView(TextView(context).apply {
                text = "Uso: aggiungi “Distanza oggi” ai Toy attivi. Quando lo selezioni con il Glyph Button vedrai i km; pressione lunga per aggiornare subito."
                textSize = 15f
            }, lp())
        }
    }

    private fun requestHealthPermissions() {
        val permissions = setOf(
            HealthPermission.getReadPermission(DistanceRecord::class),
            HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND
        )
        permissionLauncher.launch(permissions)
    }

    private fun refreshStatus(showDistance: Boolean = false) {
        lifecycleScope.launch {
            val granted = healthClient.permissionController.getGrantedPermissions()
            val read = HealthPermission.getReadPermission(DistanceRecord::class)
            if (read !in granted) {
                status.text = "Accesso Health Connect: non concesso"
                return@launch
            }
            if (showDistance) {
                val km = DistanceRepository(this@MainActivity).todayKilometres()
                status.text = String.format(Locale.getDefault(), "Google Fit oggi: %.2f km", km)
            } else {
                val bg = HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND in granted
                status.text = if (bg) "Health Connect: OK · Fonte: Google Fit" else "Distanza OK; abilita anche lettura in background per il Toy"
            }
        }
    }

    private fun openGlyphToyManager() {
        val intent = Intent().apply {
            component = ComponentName(
                "com.nothing.thirdparty",
                "com.nothing.thirdparty.matrix.toys.manager.ToysManagerActivity"
            )
        }
        runCatching { startActivity(intent) }
            .recoverCatching { startActivity(Intent("android.settings.GLYPH_SETTINGS")) }
            .recoverCatching { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
    }
}
