package com.glyphdistance.toy

import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity

class PrivacyPolicyActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            setPadding(48, 64, 48, 48)
            textSize = 17f
            text = "Privacy\n\nGlyph Distance legge esclusivamente da Health Connect il dato Distanza attribuito a Google Fit, limitatamente alla giornata corrente, per mostrarne i chilometri sulla Glyph Matrix. Non cancella o modifica i dati Health Connect. Non usa Internet, non invia dati a server e non condivide informazioni con terzi."
        })
    }
}
