# Nothing Glyph Matrix SDK

GitHub Actions downloads the official Nothing `glyph-matrix-sdk-2.0.aar`
automatically before building.

For local Android Studio builds, download the same AAR from:
Nothing-Developer-Programme/GlyphMatrix-Developer-Kit
and save it here as:

`app/libs/glyph-matrix-sdk-2.0.aar`
