package com.glyphdistance.toy

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.aggregate.AggregationResult
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.metadata.DataOrigin
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class DistanceRepository(context: Context) {

    private val client = HealthConnectClient.getOrCreate(context)

    suspend fun hasAllPermissions(): Boolean {
        val granted = client.permissionController.getGrantedPermissions()
        return REQUIRED_PERMISSIONS.all { it in granted }
    }

    suspend fun todayKilometres(): Double =
        kilometresForDate(LocalDate.now(ZoneId.systemDefault()))

    suspend fun todaySteps(): Long {
        if (!hasPermission(READ_STEPS)) return 0L
        val (start, end) = todayRange()
        val result = aggregate(
            metrics = setOf(StepsRecord.COUNT_TOTAL),
            start = start,
            end = end
        )
        return result[StepsRecord.COUNT_TOTAL] ?: 0L
    }

    suspend fun todayActiveKilocalories(): Double {
        if (!hasPermission(READ_ACTIVE_CALORIES)) return 0.0
        val (start, end) = todayRange()
        val result = aggregate(
            metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
            start = start,
            end = end
        )
        return result[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]
            ?.inKilocalories ?: 0.0
    }

    suspend fun kilometresForDate(date: LocalDate): Double {
        if (!hasPermission(READ_DISTANCE)) return 0.0

        val zone = ZoneId.systemDefault()
        val start = date.atStartOfDay(zone).toInstant()
        val nextDay = date.plusDays(1).atStartOfDay(zone).toInstant()
        val end = if (date == LocalDate.now(zone)) Instant.now() else nextDay

        // Future dates in the current week intentionally show 0.00.
        if (start.isAfter(Instant.now())) return 0.0

        val result = aggregate(
            metrics = setOf(DistanceRecord.DISTANCE_TOTAL),
            start = start,
            end = end
        )

        return result[DistanceRecord.DISTANCE_TOTAL]?.inKilometers ?: 0.0
    }

    private suspend fun hasPermission(permission: String): Boolean {
        return permission in client.permissionController.getGrantedPermissions()
    }

    private fun todayRange(): Pair<Instant, Instant> {
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now(zone).atStartOfDay(zone).toInstant()
        return start to Instant.now()
    }

    private suspend fun aggregate(
        metrics: Set<androidx.health.connect.client.aggregate.AggregateMetric<*>>,
        start: Instant,
        end: Instant
    ): AggregationResult {
        return client.aggregate(
            AggregateRequest(
                metrics = metrics,
                timeRangeFilter = TimeRangeFilter.between(start, end),
                dataOriginFilter = setOf(DataOrigin(GOOGLE_FIT_PACKAGE))
            )
        )
    }

    companion object {
        const val GOOGLE_FIT_PACKAGE = "com.google.android.apps.fitness"

        val READ_DISTANCE: String =
            HealthPermission.getReadPermission(DistanceRecord::class)

        val READ_STEPS: String =
            HealthPermission.getReadPermission(StepsRecord::class)

        val READ_ACTIVE_CALORIES: String =
            HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class)

        const val READ_BACKGROUND =
            "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND"

        val REQUIRED_PERMISSIONS = setOf(
            READ_DISTANCE,
            READ_STEPS,
            READ_ACTIVE_CALORIES,
            READ_BACKGROUND
        )
    }
}
