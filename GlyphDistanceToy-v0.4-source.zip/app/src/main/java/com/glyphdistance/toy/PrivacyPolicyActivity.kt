package com.glyphdistance.toy

import android.os.Bundle
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity

class PrivacyPolicyActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()

        val text = TextView(this).apply {
            textSize = 16f
            setPadding(pad, pad, pad, pad)
            text = """
                Privacy — Glyph Distance

                Glyph Distance legge esclusivamente da Health Connect i dati attribuiti a Google Fit necessari al Toy:
                • distanza;
                • passi;
                • calorie attive.

                La schermata settimanale legge soltanto la settimana corrente.

                L'app non cancella né modifica dati Health Connect.
                Non usa Internet.
                Non invia dati a server.
                Non condivide informazioni con terzi.
            """.trimIndent()
        }

        setContentView(
            ScrollView(this).apply {
                addView(
                    text,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            }
        )
    }
}
