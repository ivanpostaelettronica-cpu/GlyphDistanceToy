package com.glyphdistance.toy

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class SetupActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var permissionButton: Button

    private val permissions = DistanceRepository.REQUIRED_PERMISSIONS

    private val requestPermissions =
        registerForActivityResult(PermissionController.createRequestPermissionResultContract()) {
            refreshStatusAndMaybeHideIcon()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshStatusAndMaybeHideIcon()
    }

    private fun buildUi() {
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val title = TextView(this).apply {
            text = "Glyph Distance"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
        }

        val description = TextView(this).apply {
            text = """
                Dati Google Fit via Health Connect.

                Pressione lunga sul Glyph Button:
                Distanza → Passi → kcal attive → Lun → Mar → Mer → Gio → Ven → Sab → Dom.
            """.trimIndent()
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 0, 0, pad)
        }

        permissionButton = Button(this).apply {
            text = "Concedi accesso Health Connect"
            setOnClickListener {
                requestPermissions.launch(permissions)
            }
        }

        val toysButton = Button(this).apply {
            text = "Apri gestione Glyph Toys"
            setOnClickListener { openGlyphToyManager() }
        }

        val privacyButton = Button(this).apply {
            text = "Privacy"
            setOnClickListener {
                startActivity(Intent(this@SetupActivity, PrivacyPolicyActivity::class.java))
            }
        }

        root.addView(title)
        root.addView(description)
        root.addView(status)
        root.addView(permissionButton)
        root.addView(toysButton)
        root.addView(privacyButton)

        setContentView(root)
    }

    private fun refreshStatusAndMaybeHideIcon() {
        lifecycleScope.launch {
            val availability = HealthConnectClient.getSdkStatus(this@SetupActivity)

            if (availability != HealthConnectClient.SDK_AVAILABLE) {
                status.text = "Health Connect non disponibile su questo dispositivo."
                permissionButton.isEnabled = false
                return@launch
            }

            val client = HealthConnectClient.getOrCreate(this@SetupActivity)
            val granted = client.permissionController.getGrantedPermissions()
            val missing = permissions.filterNot { it in granted }

            if (missing.isEmpty()) {
                status.text = "Health Connect: OK. L'icona di configurazione verrà nascosta."
                permissionButton.isEnabled = false
                hideLauncherIcon()
            } else {
                status.text =
                    "Servono i permessi per distanza, passi, calorie attive e lettura in background."
                permissionButton.isEnabled = true
            }
        }
    }

    private fun hideLauncherIcon() {
        val alias = ComponentName(this, "com.glyphdistance.toy.LauncherAlias")
        packageManager.setComponentEnabledSetting(
            alias,
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    private fun openGlyphToyManager() {
        val intents = listOf(
            Intent().setComponent(
                ComponentName(
                    "com.nothing.thirdparty",
                    "com.nothing.thirdparty.matrix.toys.manager.ToysManagerActivity"
                )
            ),
            Intent("android.settings.GLYPH_SETTINGS")
        )

        for (intent in intents) {
            try {
                startActivity(intent)
                return
            } catch (_: Throwable) {
                // Try next fallback.
            }
        }
    }
}
