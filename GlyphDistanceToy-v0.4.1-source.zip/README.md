# Glyph Distance Toy v0.4.1

Glyph Toy for Nothing Phone (3) using Google Fit data through Health Connect.

## Long-press screens

Every long press on the Glyph Button advances one page:

1. Today distance — `KM`
2. Today steps — `PASSI`
3. Today active calories — `KCAL`
4. Monday distance — `LU`
5. Tuesday distance — `MA`
6. Wednesday distance — `ME`
7. Thursday distance — `GI`
8. Friday distance — `VE`
9. Saturday distance — `SA`
10. Sunday distance — `DO`

The next long press returns to today's distance.

## Display

Distance is rendered with a compact 3x5 pixel font and two decimal places
up to `99,99`, so the complete value fits inside the 25x25 Glyph Matrix.

## Data

- Google Fit is filtered as Health Connect data origin.
- Distance, steps and active calories are read only.
- Weekly pages refer to the current Monday-Sunday week.
- Future days of the current week show `0,00`.
- The active page refreshes every 60 seconds.
- No Health Connect data is written or deleted.
- No Internet permission is requested.

## Launcher icon

The setup icon exists only to request Health Connect permissions on first
installation. After all required permissions are granted, the launcher alias
is disabled automatically. The Glyph Toy remains available.

## Build on GitHub

1. Upload the contents of this ZIP to the repository root.
2. Open **Actions**.
3. Run **Build GlyphDistanceToy APK**.
4. Open the completed workflow.
5. Under **Artifacts**, download **GlyphDistanceToy-APK**.
6. Extract and install `GlyphDistanceToy-v0.4.1.apk`.

The workflow downloads the official Nothing Glyph Matrix SDK automatically.

## Important when upgrading

This version requests two additional Health Connect data permissions:
Steps and Active Calories Burned. Open the setup page once after installation
and grant the new permissions before the launcher icon hides.


## v0.4.1

Build fix: compileSdk/targetSdk updated to Android API 36, required by Health Connect 1.1.0.
