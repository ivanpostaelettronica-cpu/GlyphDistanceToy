# Changelog

## [0.6.0] - 2026-08-13

### Added
- Selectable Health Connect source: all providers or Google Fit only.
- Default source is all Health Connect providers.

### Changed
- Maximum requested Glyph intensity remains 255 for every illuminated pixel.
- Removed unused background Health Connect permission.
- Simplified Health Connect permission model.
- Cleaned documentation and build packaging for public distribution.

### Notes
- v0.6.0 is a release candidate intended for physical-device validation before v1.0.0.
- Actual perceived Glyph brightness may still be affected by Nothing OS, firmware or SDK behavior.

## [0.5.1] - 2026-08-13

### Fixed
- Consolidated renderer brightness into one maximum-intensity constant.
- Improved defensive handling in weekly page navigation.

## [0.5.0] - 2026-08-10

### Changed
- Raised intentionally illuminated renderer pixels to maximum matrix intensity.
- Added open-source distribution documentation.

## [0.4.2] - 2026-08-09

### Fixed
- Health Connect permission integration.
- Android API 36 build compatibility.

### Added
- Today distance, steps and active calories.
- Monday–Sunday distance pages.
