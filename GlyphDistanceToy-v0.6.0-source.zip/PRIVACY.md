# Privacy Policy — Glyph Distance Toy

Last updated: 13 August 2026

Glyph Distance Toy operates locally on the Android device.

## Data accessed

With explicit Health Connect permission, the application reads:
- distance;
- steps;
- active calories.

The user can choose between:
- all Health Connect data providers;
- Google Fit only.

## Purpose

These values are used only to render fitness information on the Nothing Phone (3) Glyph Matrix.

## Transmission

The application does not request Android's Internet permission and does not contain analytics, advertising, account login or an application server.

Fitness records are not uploaded by Glyph Distance Toy.

## Modification

Glyph Distance Toy does not create, modify or delete Health Connect fitness records.

## Permission control

Health Connect permissions can be revoked at any time in Android settings.

## Third parties

Health Connect, Google Fit, Android and the Nothing Glyph Matrix platform are third-party products governed by their respective terms and policies.

## Public issue reports

Do not include personal health information in public GitHub issues.
