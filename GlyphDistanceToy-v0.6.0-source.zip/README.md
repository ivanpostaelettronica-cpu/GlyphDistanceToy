# Glyph Distance Toy v0.6.0 RC

An open-source Glyph Toy for **Nothing Phone (3)** that displays fitness information on the 25×25 Glyph Matrix.

> Independent community project. Not affiliated with, endorsed by, or sponsored by Nothing Technology Limited or Google LLC.

## What changed in v0.6.0

- Maximum requested Glyph intensity (`255`) remains enabled for every illuminated pixel.
- Health Connect source is now selectable:
  - **All Health Connect providers** — default;
  - **Google Fit only**.
- Removed the unused Health Connect background-read permission.
- Health data permissions are limited to distance, steps and active calories.
- Repository documentation and build packaging were cleaned up for public distribution.
- The Toy still cycles through today metrics and current-week daily distance.

## Glyph pages

Long-press the Glyph Button:

1. Today distance — `KM`
2. Today steps — `PASSI`
3. Today active calories — `KCAL`
4. Monday — `LU`
5. Tuesday — `MA`
6. Wednesday — `ME`
7. Thursday — `GI`
8. Friday — `VE`
9. Saturday — `SA`
10. Sunday — `DO`

The next long press returns to today's distance.

## Data source

The default is **All Health Connect providers**. This is more useful for public distribution because the Toy can use records written by compatible fitness apps and devices.

Users who want the original behavior can select **Google Fit only** in the setup screen.

## Permissions

The app requests read access only to:

- Distance
- Steps
- Active calories

It does **not** request Health Connect background-read permission.

The app does not request Android's Internet permission.

## Privacy

Fitness values are read locally from Health Connect and rendered on the Glyph Matrix. The application contains no analytics, advertising or application-level network upload.

See [PRIVACY.md](PRIVACY.md).

## Setup

1. Install the APK.
2. Open **Glyph Distance** once.
3. Choose the Health Connect data source.
4. Grant distance, steps and active-calorie permissions.
5. Open the Glyph Toys manager and select **Distance**.

After onboarding, the launcher icon is hidden as in previous versions. The setup Activity remains registered as the Glyph Toy introduction page.

## Build

### Recommended public repository layout

For a normal open-source repository, extract this archive into the repository root so that `app/`, `README.md`, `LICENSE`, etc. are directly visible.

### Single-ZIP workflow used from iPad

If you prefer to upload the source as one ZIP, use the separately supplied repository workflow:

`build-apk-GlyphDistanceToy-v0.6.0.yml`

It extracts this archive into an isolated `buildsrc/` directory and compiles only that source, preventing old repository files from being picked up accidentally.

## Release status

`0.6.0` is a **release candidate**. Test on a physical Nothing Phone (3) before publishing a stable `1.0.0`.

In particular verify:
- Glyph visibility/brightness;
- each long-press page;
- Health Connect values with “All providers” and “Google Fit only”;
- day/week transitions;
- permission onboarding.

## License

GNU General Public License v3.0 or later. See [LICENSE](LICENSE).
