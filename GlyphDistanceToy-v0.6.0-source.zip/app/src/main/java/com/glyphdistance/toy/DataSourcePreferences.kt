package com.glyphdistance.toy

import android.content.Context

enum class HealthDataSource {
    ALL,
    GOOGLE_FIT
}

class DataSourcePreferences(context: Context) {

    private val prefs =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getSource(): HealthDataSource {
        return when (prefs.getString(KEY_SOURCE, HealthDataSource.ALL.name)) {
            HealthDataSource.GOOGLE_FIT.name -> HealthDataSource.GOOGLE_FIT
            else -> HealthDataSource.ALL
        }
    }

    fun setSource(source: HealthDataSource) {
        prefs.edit()
            .putString(KEY_SOURCE, source.name)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "glyph_distance_preferences"
        private const val KEY_SOURCE = "health_data_source"
    }
}
