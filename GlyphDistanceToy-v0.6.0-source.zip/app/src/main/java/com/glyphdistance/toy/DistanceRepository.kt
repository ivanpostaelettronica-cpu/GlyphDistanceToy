package com.glyphdistance.toy

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.aggregate.AggregationResult
import androidx.health.connect.client.aggregate.AggregateMetric
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.metadata.DataOrigin
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class DistanceRepository(context: Context) {

    private val client = HealthConnectClient.getOrCreate(context)
    private val sourcePreferences = DataSourcePreferences(context)

    suspend fun hasCorePermissions(): Boolean {
        val granted = client.permissionController.getGrantedPermissions()
        return CORE_PERMISSIONS.all { it in granted }
    }

    suspend fun hasDistancePermission(): Boolean =
        hasPermission(READ_DISTANCE)

    suspend fun hasStepsPermission(): Boolean =
        hasPermission(READ_STEPS)

    suspend fun hasActiveCaloriesPermission(): Boolean =
        hasPermission(READ_ACTIVE_CALORIES)

    suspend fun todayKilometres(): Double =
        kilometresForDate(LocalDate.now(ZoneId.systemDefault()))

    suspend fun todaySteps(): Long {
        if (!hasStepsPermission()) return 0L

        val (start, end) = todayRange()
        val result = aggregate(
            metrics = setOf(StepsRecord.COUNT_TOTAL),
            start = start,
            end = end
        )

        return result[StepsRecord.COUNT_TOTAL] ?: 0L
    }

    suspend fun todayActiveKilocalories(): Double {
        if (!hasActiveCaloriesPermission()) return 0.0

        val (start, end) = todayRange()
        val result = aggregate(
            metrics = setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL),
            start = start,
            end = end
        )

        return result[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]
            ?.inKilocalories ?: 0.0
    }

    suspend fun kilometresForDate(date: LocalDate): Double {
        if (!hasDistancePermission()) return 0.0

        val zone = ZoneId.systemDefault()
        val now = Instant.now()
        val today = LocalDate.now(zone)
        val start = date.atStartOfDay(zone).toInstant()

        if (start.isAfter(now)) return 0.0

        val nextDay = date.plusDays(1)
            .atStartOfDay(zone)
            .toInstant()

        val end =
            if (date == today) now
            else nextDay

        val result = aggregate(
            metrics = setOf(DistanceRecord.DISTANCE_TOTAL),
            start = start,
            end = end
        )

        return result[DistanceRecord.DISTANCE_TOTAL]
            ?.inKilometers ?: 0.0
    }

    private suspend fun hasPermission(permission: String): Boolean {
        return permission in
            client.permissionController.getGrantedPermissions()
    }

    private fun todayRange(): Pair<Instant, Instant> {
        val zone = ZoneId.systemDefault()
        val start = LocalDate.now(zone)
            .atStartOfDay(zone)
            .toInstant()

        return start to Instant.now()
    }

    private suspend fun aggregate(
        metrics: Set<AggregateMetric<*>>,
        start: Instant,
        end: Instant
    ): AggregationResult {

        val origins =
            when (sourcePreferences.getSource()) {
                HealthDataSource.ALL ->
                    emptySet()

                HealthDataSource.GOOGLE_FIT ->
                    setOf(DataOrigin(GOOGLE_FIT_PACKAGE))
            }

        return client.aggregate(
            AggregateRequest(
                metrics = metrics,
                timeRangeFilter = TimeRangeFilter.between(start, end),
                dataOriginFilter = origins
            )
        )
    }

    companion object {
        const val GOOGLE_FIT_PACKAGE =
            "com.google.android.apps.fitness"

        val READ_DISTANCE: String =
            HealthPermission.getReadPermission(DistanceRecord::class)

        val READ_STEPS: String =
            HealthPermission.getReadPermission(StepsRecord::class)

        val READ_ACTIVE_CALORIES: String =
            HealthPermission.getReadPermission(
                ActiveCaloriesBurnedRecord::class
            )

        val CORE_PERMISSIONS = setOf(
            READ_DISTANCE,
            READ_STEPS,
            READ_ACTIVE_CALORIES
        )
    }
}
