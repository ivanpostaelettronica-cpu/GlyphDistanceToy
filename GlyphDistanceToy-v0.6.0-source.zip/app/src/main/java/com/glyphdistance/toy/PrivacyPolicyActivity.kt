package com.glyphdistance.toy

import android.os.Bundle
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity

class PrivacyPolicyActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad =
            (24 * resources.displayMetrics.density).toInt()

        val text = TextView(this).apply {
            textSize = 16f
            setPadding(pad, pad, pad, pad)

            text = """
                Privacy — Glyph Distance

                Glyph Distance legge esclusivamente da Health Connect:
                • distanza;
                • passi;
                • calorie attive.

                Per impostazione predefinita vengono considerati tutti i provider
                presenti in Health Connect. L'utente può scegliere di limitare
                i dati al solo Google Fit.

                L'app non scrive, modifica o elimina dati Health Connect.
                Non richiede il permesso Internet.
                Non usa analytics o pubblicità.
                Non invia dati a server.
            """.trimIndent()
        }

        setContentView(
            ScrollView(this).apply {
                addView(
                    text,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            }
        )
    }
}
