package com.glyphdistance.toy

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class SetupActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var permissionButton: Button
    private lateinit var sourceSpinner: Spinner
    private lateinit var sourcePreferences: DataSourcePreferences

    private val permissions =
        DistanceRepository.CORE_PERMISSIONS

    private val requestPermissions =
        registerForActivityResult(
            PermissionController
                .createRequestPermissionResultContract()
        ) {
            refreshStatusAndMaybeHideIcon()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sourcePreferences =
            DataSourcePreferences(applicationContext)

        buildUi()
        refreshStatusAndMaybeHideIcon()
    }

    private fun buildUi() {
        val pad =
            (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad, pad, pad)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val title = TextView(this).apply {
            text = "Glyph Distance"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
        }

        val description = TextView(this).apply {
            text = """
                Fitness su Glyph Matrix.

                Pressione lunga sul Glyph Button:
                Distanza → Passi → kcal attive →
                Lun → Mar → Mer → Gio → Ven → Sab → Dom.
            """.trimIndent()
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }

        val sourceLabel = TextView(this).apply {
            text = "Origine dati Health Connect"
            textSize = 16f
        }

        sourceSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@SetupActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf(
                    "Tutti i provider Health Connect",
                    "Solo Google Fit"
                )
            )

            setSelection(
                when (sourcePreferences.getSource()) {
                    HealthDataSource.ALL -> 0
                    HealthDataSource.GOOGLE_FIT -> 1
                }
            )
        }

        val saveSourceButton = Button(this).apply {
            text = "Salva origine dati"
            setOnClickListener {
                val source =
                    if (sourceSpinner.selectedItemPosition == 1)
                        HealthDataSource.GOOGLE_FIT
                    else
                        HealthDataSource.ALL

                sourcePreferences.setSource(source)

                Toast.makeText(
                    this@SetupActivity,
                    "Origine dati aggiornata.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad, 0, pad)
        }

        permissionButton = Button(this).apply {
            text = "Concedi accesso Health Connect"
            setOnClickListener {
                requestPermissions.launch(permissions)
            }
        }

        val toysButton = Button(this).apply {
            text = "Apri gestione Glyph Toys"
            setOnClickListener {
                openGlyphToyManager()
            }
        }

        val privacyButton = Button(this).apply {
            text = "Privacy"
            setOnClickListener {
                startActivity(
                    Intent(
                        this@SetupActivity,
                        PrivacyPolicyActivity::class.java
                    )
                )
            }
        }

        root.addView(title)
        root.addView(description)
        root.addView(sourceLabel)
        root.addView(sourceSpinner)
        root.addView(saveSourceButton)
        root.addView(status)
        root.addView(permissionButton)
        root.addView(toysButton)
        root.addView(privacyButton)

        setContentView(root)
    }

    private fun refreshStatusAndMaybeHideIcon() {
        lifecycleScope.launch {
            val availability =
                HealthConnectClient.getSdkStatus(
                    this@SetupActivity
                )

            if (
                availability !=
                HealthConnectClient.SDK_AVAILABLE
            ) {
                status.text =
                    "Health Connect non disponibile su questo dispositivo."
                permissionButton.isEnabled = false
                return@launch
            }

            val client =
                HealthConnectClient.getOrCreate(
                    this@SetupActivity
                )

            val granted =
                client.permissionController
                    .getGrantedPermissions()

            val missing =
                permissions.filterNot {
                    it in granted
                }

            if (missing.isEmpty()) {
                status.text =
                    "Health Connect: autorizzazioni OK."
                permissionButton.isEnabled = false

                // Keep the previous user-requested behavior:
                // the setup icon disappears after onboarding.
                hideLauncherIcon()
            } else {
                status.text =
                    "Servono i permessi per distanza, passi e calorie attive."
                permissionButton.isEnabled = true
            }
        }
    }

    private fun hideLauncherIcon() {
        val alias =
            ComponentName(
                this,
                "com.glyphdistance.toy.LauncherAlias"
            )

        packageManager.setComponentEnabledSetting(
            alias,
            PackageManager
                .COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }

    private fun openGlyphToyManager() {
        val intents = listOf(
            Intent().setComponent(
                ComponentName(
                    "com.nothing.thirdparty",
                    "com.nothing.thirdparty.matrix.toys.manager.ToysManagerActivity"
                )
            ),
            Intent("android.settings.GLYPH_SETTINGS")
        )

        for (intent in intents) {
            try {
                startActivity(intent)
                return
            } catch (_: Throwable) {
            }
        }

        Toast.makeText(
            this,
            "Apri manualmente la gestione Glyph Toys dalle impostazioni.",
            Toast.LENGTH_LONG
        ).show()
    }
}
