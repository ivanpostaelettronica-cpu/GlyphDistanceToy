---
name: Bug report
about: Report a reproducible problem
title: "[Bug] "
labels: bug
---

**Version**
**Nothing Phone / Nothing OS version**
**Expected behavior**
**Actual behavior**
**Steps to reproduce**
**Relevant logs/screenshots**

Do not include personal health data, credentials, or signing material.
