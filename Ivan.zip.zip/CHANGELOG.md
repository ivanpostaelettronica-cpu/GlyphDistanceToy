# Changelog

All notable project changes are documented here.

## [0.5.0] - 2026-08-10

### Changed
- Raised all intentionally illuminated renderer pixels to the maximum matrix value (`255`) to improve Glyph visibility.
- Added complete open-source distribution documentation.
- Adopted GPL-3.0-or-later licensing.
- Added privacy, security, contribution, notice, release and disclaimer documentation.

### Important
The renderer now requests maximum pixel intensity. Actual perceived brightness can still be limited by Nothing OS, firmware, system settings, or SDK behavior.

## [0.4.2] - 2026-08-09

### Fixed
- Updated compile/target SDK to Android API 36 for Health Connect 1.1.0 compatibility.
- Corrected Health Connect permission integration for Android 14+.
- Added per-page permission checks.
- Background Health Connect read permission remains optional for initial setup.

### Features
- Today distance, steps and active calories.
- Current-week daily distance pages.
- Google Fit data origin filtering through Health Connect.
- 60-second refresh.
