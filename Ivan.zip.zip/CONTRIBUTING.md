# Contributing

Contributions, bug reports, documentation improvements, and tested compatibility reports are welcome.

## Before submitting code

1. Base changes on the latest repository version.
2. Keep the app local-first and privacy-preserving.
3. Do not add analytics, advertising, tracking, or network access without an explicit design discussion.
4. Do not commit proprietary SDK binaries unless redistribution is clearly permitted.
5. Do not commit credentials, signing material, personal data, or Health Connect exports.
6. Confirm the project builds successfully.
7. Describe the Nothing Phone/Nothing OS version used for device testing when relevant.

By contributing code, you agree that your contribution may be distributed under the project's GPL-3.0-or-later license.
