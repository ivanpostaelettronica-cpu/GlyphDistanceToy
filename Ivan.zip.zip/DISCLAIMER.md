# Disclaimer

Glyph Distance Toy is provided without warranty, to the extent permitted by applicable law, under the terms of the GNU GPL.

Fitness values displayed by the Toy depend on Health Connect and the originating data provider. They may be delayed, incomplete, unavailable, or inaccurate. The application is not a medical device and must not be used for medical diagnosis, treatment, emergency monitoring, or safety-critical decisions.

This project is independent and is not affiliated with, endorsed by, or sponsored by Nothing Technology Limited or Google LLC.
