# Privacy Policy — Glyph Distance Toy

Last updated: 10 August 2026

Glyph Distance Toy is designed to operate locally on the Android device.

## Data accessed

When permission is granted, the app reads the following Health Connect data:
- distance;
- steps;
- active calories.

The current implementation filters aggregation to records attributed to Google Fit (`com.google.android.apps.fitness`).

## Purpose

The data is used only to render the selected fitness value on the Nothing Phone (3) Glyph Matrix.

## Data transmission and storage

The application does not request Android's Internet permission and contains no application code intended to upload fitness data to a remote server, advertising service, or analytics service.

The application does not write, modify, or delete Health Connect records.

## Permissions

Health Connect permissions are controlled by Android. You can revoke them through the device's Health Connect settings.

## Third-party software

The project uses Android/AndroidX components and the Nothing Glyph Matrix SDK. Google Fit and Health Connect are separate products/services governed by their respective terms and privacy policies.

## Contact

For project questions or privacy issues, open an issue in the project's GitHub repository. Do not include sensitive health information in a public issue.
