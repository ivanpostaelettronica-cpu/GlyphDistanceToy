# Glyph Distance Toy

An open-source Glyph Toy for **Nothing Phone (3)** that displays fitness information on the 25×25 Glyph Matrix.

> Independent community project. Not affiliated with, endorsed by, or sponsored by Nothing Technology Limited or Google LLC.

## Features

- Today's walking distance in kilometres
- Today's steps
- Today's active calories
- Distance for each day of the current Monday–Sunday week
- Automatic refresh every 60 seconds while the Toy is active
- Long press on the Glyph Button to change page
- Reads Google Fit-originated records through Health Connect
- No Internet permission
- No analytics, advertising, account, or remote server
- Maximum requested matrix brightness for the displayed pixels in v0.5.0

## Glyph pages

Long-press the Glyph Button to cycle through:

1. Today distance — `KM`
2. Today steps — `PASSI`
3. Today active calories — `KCAL`
4. Monday — `LU`
5. Tuesday — `MA`
6. Wednesday — `ME`
7. Thursday — `GI`
8. Friday — `VE`
9. Saturday — `SA`
10. Sunday — `DO`

The next long press returns to today's distance.

## Requirements

- Nothing Phone (3)
- Android version compatible with the Nothing Glyph Matrix SDK used by this project
- Health Connect available on the device
- Google Fit data synchronized into Health Connect for the metrics you want to display

## Permissions and data access

Glyph Distance Toy requests read access to:

- Distance
- Steps
- Active calories

The app filters Health Connect aggregation to the Google Fit package (`com.google.android.apps.fitness`).

It does **not** write, modify, or delete Health Connect records. The Android Internet permission is not requested.

See [PRIVACY.md](PRIVACY.md) for the complete privacy statement.

## Installation

For normal users, install the APK attached to a GitHub Release. Android may ask you to allow installation from the app used to open the APK.

After installation:

1. Open **Glyph Distance** once.
2. Grant the requested Health Connect read permissions.
3. Open the Glyph Toys manager.
4. Select **Glyph Distance**.

The setup launcher icon is hidden after all core Health Connect permissions are granted. The Glyph Toy remains available.

## Build from source

The repository includes a GitHub Actions workflow.

1. Put the project files at the repository root.
2. Open **Actions** on GitHub.
3. Run **Build GlyphDistanceToy APK**.
4. Download the generated artifact.

The workflow downloads the Nothing Glyph Matrix SDK AAR during the build. The SDK is not included in this repository.

### Toolchain

- Java 17
- Gradle 8.11.1 in the current CI workflow
- Android compile/target SDK 36
- Nothing Glyph Matrix SDK 2.0
- AndroidX Health Connect Client 1.1.0

## Releases and verification

Published release APKs should be accompanied by a SHA-256 checksum. Verify a downloaded APK against the checksum before installing it.

For long-term public distribution, use a stable release signing key and protect it carefully. Do not commit private signing keys or passwords to the repository.

## Known limitations

- Values depend on the data actually available in Health Connect.
- The app intentionally reads only records attributed to Google Fit.
- Future days in the current week display zero.
- Maximum brightness values are requested by the renderer, but perceived Glyph brightness can still be affected by Nothing OS, device firmware, system behavior, or the Glyph SDK.

## Security

Please read [SECURITY.md](SECURITY.md) before reporting a security issue.

## Contributing

Contributions are welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

Copyright © Glyph Distance Toy contributors.

This project is free software licensed under the **GNU General Public License v3.0 or later (GPL-3.0-or-later)**. See [LICENSE](LICENSE).

Third-party components and trademarks remain subject to their respective licenses and owners. See [NOTICE](NOTICE).
