# Release Checklist

1. Confirm the version name/code.
2. Build and test on a physical Nothing Phone (3).
3. Verify Health Connect permission onboarding.
4. Verify every Glyph page.
5. Verify behavior across midnight/day change.
6. Build the release APK with the project's stable signing key.
7. Generate SHA-256:
   `sha256sum GlyphDistanceToy-vX.Y.Z.apk > SHA256SUMS.txt`
8. Create a signed/tagged Git version such as `v0.5.0`.
9. Create a GitHub Release and attach the APK plus `SHA256SUMS.txt`.
10. Copy the relevant CHANGELOG section into the release notes.
11. Never upload the private signing key or its password.
