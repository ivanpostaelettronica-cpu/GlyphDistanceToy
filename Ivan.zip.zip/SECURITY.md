# Security Policy

## Supported versions

Security fixes are intended for the latest published version.

## Reporting a vulnerability

Do not publish sensitive vulnerability details, personal data, Health Connect data, credentials, signing keys, or tokens in a public issue.

Use GitHub's private vulnerability reporting feature if it is enabled for the repository. If it is not enabled, open a minimal public issue requesting a private contact channel without disclosing exploit details.

## Build and release security

- Never commit keystores, private signing keys, passwords, access tokens, or GitHub secrets.
- Use a dedicated, backed-up Android release signing key for public releases.
- Store CI secrets only in GitHub Actions Secrets.
- Publish SHA-256 checksums with releases.
- Review dependency updates before merging them.
