package com.glyphdistance.toy

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphMatrixManager
import com.nothing.ketchum.GlyphToy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

class DistanceGlyphToyService : android.app.Service() {

    private var glyphManager: GlyphMatrixManager? = null
    private var refreshJob: Job? = null
    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var repository: DistanceRepository

    // 0=distance, 1=steps, 2=active kcal, 3..9=Mon..Sun distance
    private var page = 0

    private val callback = object : GlyphMatrixManager.Callback {
        override fun onServiceConnected(componentName: ComponentName) {
            val manager = glyphManager ?: return
            manager.register(Glyph.DEVICE_23112)
            updateMatrix()
            startPeriodicRefresh()
        }

        override fun onServiceDisconnected(componentName: ComponentName) {
            refreshJob?.cancel()
        }
    }

    private val serviceHandler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            if (msg.what == GlyphToy.MSG_GLYPH_TOY) {
                val bundle: Bundle = msg.data
                val event = bundle.getString(GlyphToy.MSG_GLYPH_TOY_DATA)

                if (GlyphToy.EVENT_CHANGE == event) {
                    page = (page + 1) % TOTAL_PAGES
                    updateMatrix()
                    return
                }
            }
            super.handleMessage(msg)
        }
    }

    private val serviceMessenger = Messenger(serviceHandler)

    override fun onCreate() {
        super.onCreate()
        repository = DistanceRepository(applicationContext)
    }

    override fun onBind(intent: Intent?): IBinder {
        if (scope.coroutineContext[Job]?.isCancelled == true) {
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        }

        page = 0

        glyphManager = GlyphMatrixManager.getInstance(applicationContext).also {
            it.init(callback)
        }

        return serviceMessenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        refreshJob?.cancel()
        refreshJob = null
        glyphManager?.unInit()
        glyphManager = null
        scope.cancel()
        return false
    }

    private fun startPeriodicRefresh() {
        refreshJob?.cancel()
        refreshJob = scope.launch {
            while (isActive) {
                updateMatrix()
                delay(60_000L)
            }
        }
    }

    private fun updateMatrix() {
        scope.launch {
            val frame = try {
                when (page) {
                    0 -> if (repository.hasDistancePermission()) {
                        DistanceMatrixRenderer.renderDistance(repository.todayKilometres(), "KM")
                    } else {
                        DistanceMatrixRenderer.renderNoPermission()
                    }

                    1 -> if (repository.hasStepsPermission()) {
                        DistanceMatrixRenderer.renderSteps(repository.todaySteps())
                    } else {
                        DistanceMatrixRenderer.renderNoPermission()
                    }

                    2 -> if (repository.hasActiveCaloriesPermission()) {
                        DistanceMatrixRenderer.renderCalories(repository.todayActiveKilocalories())
                    } else {
                        DistanceMatrixRenderer.renderNoPermission()
                    }

                    else -> if (repository.hasDistancePermission()) {
                        val index = page - 3 // 0=Mon ... 6=Sun
                        val monday = LocalDate.now(ZoneId.systemDefault())
                            .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                        val date = monday.plusDays(index.toLong())

                        DistanceMatrixRenderer.renderDistance(
                            repository.kilometresForDate(date),
                            DAY_LABELS[index]
                        )
                    } else {
                        DistanceMatrixRenderer.renderNoPermission()
                    }
                }
            } catch (_: Throwable) {
                DistanceMatrixRenderer.renderNoPermission()
            }

            glyphManager?.setMatrixFrame(frame)
        }
    }

    companion object {
        private const val TOTAL_PAGES = 10

        private val DAY_LABELS = listOf(
            "LU", "MA", "ME", "GI", "VE", "SA", "DO"
        )
    }
}
