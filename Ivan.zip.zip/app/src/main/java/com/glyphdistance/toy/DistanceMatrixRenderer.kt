package com.glyphdistance.toy

import kotlin.math.min

object DistanceMatrixRenderer {

    private const val W = 25
    private const val H = 25
    private const val ON = 255
    private const val LABEL = 255
    private const val DIM = 255

    // Compact 3x5 font: 99,99 occupies only 19 of the 25 columns.
    private val font = mapOf(
        '0' to arrayOf("###", "#.#", "#.#", "#.#", "###"),
        '1' to arrayOf(".#.", "##.", ".#.", ".#.", "###"),
        '2' to arrayOf("###", "..#", "###", "#..", "###"),
        '3' to arrayOf("###", "..#", "###", "..#", "###"),
        '4' to arrayOf("#.#", "#.#", "###", "..#", "..#"),
        '5' to arrayOf("###", "#..", "###", "..#", "###"),
        '6' to arrayOf("###", "#..", "###", "#.#", "###"),
        '7' to arrayOf("###", "..#", "..#", "..#", "..#"),
        '8' to arrayOf("###", "#.#", "###", "#.#", "###"),
        '9' to arrayOf("###", "#.#", "###", "..#", "###"),
        ',' to arrayOf("...", "...", "...", ".#.", "#.."),
        '-' to arrayOf("...", "...", "###", "...", "..."),

        'A' to arrayOf(".#.", "#.#", "###", "#.#", "#.#"),
        'C' to arrayOf("###", "#..", "#..", "#..", "###"),
        'D' to arrayOf("##.", "#.#", "#.#", "#.#", "##."),
        'E' to arrayOf("###", "#..", "##.", "#..", "###"),
        'G' to arrayOf("###", "#..", "#.#", "#.#", "###"),
        'I' to arrayOf("###", ".#.", ".#.", ".#.", "###"),
        'K' to arrayOf("#.#", "##.", "#..", "##.", "#.#"),
        'L' to arrayOf("#..", "#..", "#..", "#..", "###"),
        'M' to arrayOf("#.#", "###", "###", "#.#", "#.#"),
        'O' to arrayOf("###", "#.#", "#.#", "#.#", "###"),
        'P' to arrayOf("##.", "#.#", "##.", "#..", "#.."),
        'S' to arrayOf("###", "#..", "###", "..#", "###"),
        'T' to arrayOf("###", ".#.", ".#.", ".#.", ".#."),
        'V' to arrayOf("#.#", "#.#", "#.#", "#.#", ".#.")
    )

    fun renderDistance(km: Double, label: String = "KM"): IntArray {
        val value = when {
            km < 100.0 -> format2(km.coerceAtMost(99.99))
            else -> min(km, 999.0).toInt().toString()
        }
        return renderValue(value, label)
    }

    fun renderSteps(steps: Long): IntArray {
        val value = steps.coerceIn(0L, 99999L).toString()
        return renderValue(value, "PASSI")
    }

    fun renderCalories(kcal: Double): IntArray {
        val value = min(kcal, 9999.0).toInt().toString()
        return renderValue(value, "KCAL")
    }

    fun renderNoPermission(): IntArray {
        val grid = IntArray(W * H)
        for (y in 5..15) set(grid, 12, y, ON)
        set(grid, 12, 19, ON)
        return grid
    }

    private fun format2(value: Double): String {
        // Italian decimal separator, fixed two decimals.
        return String.format(java.util.Locale.US, "%.2f", value)
            .replace('.', ',')
    }

    private fun renderValue(value: String, label: String): IntArray {
        val grid = IntArray(W * H)

        // Small guide dots keep the Toy visually anchored without stealing space.
        for (x in 2 until W step 5) {
            set(grid, x, 1, DIM)
            set(grid, x, 23, DIM)
        }

        drawCentered(grid, value, top = 6, brightness = ON)
        drawCentered(grid, label, top = 15, brightness = LABEL)

        return grid
    }

    private fun drawCentered(
        grid: IntArray,
        text: String,
        top: Int,
        brightness: Int
    ) {
        val glyphW = 3
        val gap = 1
        val totalW = text.length * glyphW + (text.length - 1) * gap

        // If a label is too long (e.g. PASSI = 19 columns), it still fits.
        var x = ((W - totalW) / 2).coerceAtLeast(0)

        for (ch in text) {
            drawChar(grid, ch, x, top, brightness)
            x += glyphW + gap
        }
    }

    private fun drawChar(
        grid: IntArray,
        ch: Char,
        left: Int,
        top: Int,
        brightness: Int
    ) {
        val pattern = font[ch] ?: return
        pattern.forEachIndexed { py, row ->
            row.forEachIndexed { px, c ->
                if (c == '#') {
                    set(grid, left + px, top + py, brightness)
                }
            }
        }
    }

    private fun set(grid: IntArray, x: Int, y: Int, value: Int) {
        if (x in 0 until W && y in 0 until H) {
            grid[y * W + x] = value.coerceIn(0, 255)
        }
    }
}
